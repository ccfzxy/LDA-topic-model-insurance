# LDA Topic Modeling Statistics for Insurance Companies on Reddit

| Company | Original Posts | Processed Posts | Original Comments | Processed Comments | Preprocessed Texts | TF-IDF Filtered Texts | Number of Topics | Coherence Score |
|------|------------|------------|------------|------------|--------------|-------------------|----------|------------|
| Sun Life | 2472 | 2472 | 52213 | 52213 | 53562 | 42883 | 3 | 0.6886 |
| Prudential | 789 | 789 | 14837 | 14837 | 15361 | 12493 | 5 | 0.6465 |
| AXA | 661 | 661 | 13358 | 13358 | 13779 | 11261 | 4 | 0.6485 |
| AIA | 551 | 551 | 12699 | 12699 | 13019 | 10582 | 5 | 0.6392 |
| Manulife | 532 | 532 | 10398 | 10398 | 10753 | 8783 | 4 | 0.6207 |
